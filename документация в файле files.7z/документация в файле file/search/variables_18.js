var searchData=
[
  ['zero_1211',['Zero',['../struct_xD0_x9C_xD0_xB0_xD1_x82_xD0_x9A_xD0_xBB_xD0_xB0_xD1_x81_xD1_x81_xD1_x8B_1_1_point.html#a5c039a951a9e039166dd791c0f7e1488',1,'МатКлассы.Point.Zero()'],['../struct_xD0_x9C_xD0_xB0_xD1_x82_xD0_x9A_xD0_xBB_xD0_xB0_xD1_x81_xD1_x81_xD1_x8B_1_1_number_1_1_rational.html#a496a12d5c3d7cd27b1347efbadd0982e',1,'МатКлассы.Number.Rational.ZERO()']]]
];
