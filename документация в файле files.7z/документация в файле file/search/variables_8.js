var searchData=
[
  ['hmax_1151',['hmax',['../class_xD0_x9C_xD0_xB0_xD1_x82_xD0_x9A_xD0_xBB_xD0_xB0_xD1_x81_xD1_x81_xD1_x8B_1_1_polynom.html#a6adbabae1dc880e5ae80ff45c21567d8',1,'МатКлассы::Polynom']]]
];
