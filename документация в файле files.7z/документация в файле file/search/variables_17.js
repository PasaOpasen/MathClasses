var searchData=
[
  ['y_1210',['y',['../class_xD0_x9C_xD0_xB0_xD1_x82_xD0_x9A_xD0_xBB_xD0_xB0_xD1_x81_xD1_x81_xD1_x8B_1_1_multiple_knot.html#a790158e7e2d565a04ca9f103226881e8',1,'МатКлассы.MultipleKnot.y()'],['../struct_xD0_x9C_xD0_xB0_xD1_x82_xD0_x9A_xD0_xBB_xD0_xB0_xD1_x81_xD1_x81_xD1_x8B_1_1_point.html#ac70b50c996675bc76284499e039ebf8c',1,'МатКлассы.Point.y()']]]
];
