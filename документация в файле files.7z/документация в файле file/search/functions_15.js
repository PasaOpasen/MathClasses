var searchData=
[
  ['wavelet_1103',['Wavelet',['../class_xD0_x9C_xD0_xB0_xD1_x82_xD0_x9A_xD0_xBB_xD0_xB0_xD1_x81_xD1_x81_xD1_x8B_1_1_wavelet.html#ab1bf742ead8719da5ff36817b7c85a2c',1,'МатКлассы::Wavelet']]]
];
