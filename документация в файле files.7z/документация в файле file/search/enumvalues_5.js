var searchData=
[
  ['haar_1237',['HAAR',['../class_xD0_x9C_xD0_xB0_xD1_x82_xD0_x9A_xD0_xBB_xD0_xB0_xD1_x81_xD1_x81_xD1_x8B_1_1_wavelet.html#a027123cb20e107e455d9682700b73199a4d2f92f993e5175f0007b794116308c2',1,'МатКлассы::Wavelet']]],
  ['holets_1238',['Holets',['../class_xD0_x9C_xD0_xB0_xD1_x82_xD0_x9A_xD0_xBB_xD0_xB0_xD1_x81_xD1_x81_xD1_x8B_1_1_s_l_a_u.html#a734eae8bcd1381d5307245bf6897303da974ae17510dd177281c7668108629e0d',1,'МатКлассы::SLAU']]]
];
