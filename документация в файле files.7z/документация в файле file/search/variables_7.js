var searchData=
[
  ['greatestcliquessubsets_1149',['GreatestCliquesSubsets',['../class_xD0_x9C_xD0_xB0_xD1_x82_xD0_x9A_xD0_xBB_xD0_xB0_xD1_x81_xD1_x81_xD1_x8B_1_1_graphs.html#a9843ef24394013db2aac0a069355754a',1,'МатКлассы::Graphs']]],
  ['greatestindepsubsets_1150',['GreatestIndepSubsets',['../class_xD0_x9C_xD0_xB0_xD1_x82_xD0_x9A_xD0_xBB_xD0_xB0_xD1_x81_xD1_x81_xD1_x8B_1_1_graphs.html#a31872cf6eafa42901cdc2f5e877a3c6d',1,'МатКлассы::Graphs']]]
];
