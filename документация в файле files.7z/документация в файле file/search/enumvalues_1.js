var searchData=
[
  ['dog_1227',['DOG',['../class_xD0_x9C_xD0_xB0_xD1_x82_xD0_x9A_xD0_xBB_xD0_xB0_xD1_x81_xD1_x81_xD1_x8B_1_1_wavelet.html#a027123cb20e107e455d9682700b73199ab0e603b215aa2da0e6c605301d79efe4',1,'МатКлассы::Wavelet']]]
];
