var searchData=
[
  ['octnorn_1328',['OctNorn',['../class_xD0_x9C_xD0_xB0_xD1_x82_xD0_x9A_xD0_xBB_xD0_xB0_xD1_x81_xD1_x81_xD1_x8B_1_1_matrix.html#af039773526baa33e6fc4c1c7104d9f8c',1,'МатКлассы::Matrix']]]
];
